import os
import httpx
import logging

logger = logging.getLogger("Streamlabs")
logging.basicConfig(level=logging.INFO)

class StreamlabsAlert:
    def __init__(self, token: str):
        self.token = token
        self.api_url = "https://streamlabs.com/api/v1.0/alerts"

    async def send(self, event: str, message: str):
        url = f"{self.api_url}?access_token={self.token}"
        payload = {"event": event, "message": message}
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=payload)
            if resp.status_code != 200:
                logger.error(f"Streamlabs alert failed: {resp.status_code} {resp.text}")
                return False
            logger.info("Streamlabs alert sent")
            return True
