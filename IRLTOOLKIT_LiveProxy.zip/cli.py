import os
import asyncio
import typer
from stream_service import StreamIngestService
from streamlabs import StreamlabsAlert

app = typer.Typer()

def get_service():
    sources = os.getenv('STREAM_SOURCES', '').split(',')
    key = os.getenv('SRT_SECRET_KEY')
    hls_dir = os.getenv('HLS_DIR', './hls_buffer')
    buffer_segments = int(os.getenv('HLS_BUFFER', '5'))
    return StreamIngestService(sources, key, hls_dir, buffer_segments)

@app.command()
def start():
    "Start streaming ingest service"
    svc = get_service()
    asyncio.run(svc.start())
    typer.echo("Ingest started.")

@app.command()
def stop():
    "Stop streaming ingest service"
    svc = get_service()
    asyncio.run(svc.stop())
    typer.echo("Ingest stopped and buffer cleared.")

@app.command()
def status():
    "Show current ingest status"
    svc = get_service()
    st = svc.status()
    typer.echo(f"Running: {st['running']}")
    typer.echo(f"Source: {st['current_source']}")
    typer.echo(f"Buffer files: {len(st['buffer_files'])}")
    typer.echo(f"Offline: {st['is_offline']}")

@app.command()
def switch(index: int = typer.Argument(..., help="Index of source to switch to")):
    "Switch to a different streaming source"
    svc = get_service()
    asyncio.run(svc.switch_source(index))
    typer.echo(f"Switched to source index {index}.")

@app.command()
def alert(event: str, message: str):
    "Send manual Streamlabs alert"
    token = os.getenv('STREAMLABS_TOKEN')
    if not token:
        typer.echo("STREAMLABS_TOKEN not set.")
        raise typer.Exit(code=1)
    sl = StreamlabsAlert(token)
    asyncio.run(sl.send(event, message))
    typer.echo("Alert sent.")

if __name__ == "__main__":
    app()
