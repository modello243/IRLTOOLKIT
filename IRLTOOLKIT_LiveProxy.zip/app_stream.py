import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from stream_service import StreamIngestService
from streamlabs import StreamlabsAlert

load_dotenv()

SOURCES = [s for s in os.getenv('STREAM_SOURCES', '').split(',') if s]
SRT_KEY = os.getenv('SRT_SECRET_KEY')
HLS_DIR = os.getenv('HLS_DIR', './hls_buffer')
BUFFER_SEGMENTS = int(os.getenv('HLS_BUFFER', '5'))
service = StreamIngestService(SOURCES, SRT_KEY, HLS_DIR, BUFFER_SEGMENTS)
sl_alert = StreamlabsAlert(os.getenv('STREAMLABS_TOKEN', ''))

app = FastAPI(title="IRLTOOLKIT Live Proxy")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="./frontend"), name="static")

@app.get("/")
async def serve_gui():
    with open("./frontend/index.html", "r") as f:
        return HTMLResponse(content=f.read())

@app.post('/control/start')
async def start():
    await service.start()
    return {'status': 'started', 'source': service.current}

@app.post('/control/stop')
async def stop():
    await service.stop()
    return {'status': 'stopped'}

@app.post('/control/switch/{index}')
async def switch(index: int):
    try:
        await service.switch_source(index)
        return {'status': 'switched', 'source': service.current}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get('/control/status')
def status():
    return service.status()

@app.get('/control/sources')
def get_sources():
    return {'sources': service.get_sources()}

@app.get('/hls/index.m3u8')
def playlist():
    path = os.path.join(HLS_DIR, 'index.m3u8')
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail='Playlist not ready')
    with open(path, 'r') as f:
        return HTMLResponse(content=f.read(), media_type='application/vnd.apple.mpegurl')

@app.post('/alerts/streamlabs')
async def alert(payload: dict):
    event = payload.get('event', 'notification')
    message = payload.get('message', '')
    success = await sl_alert.send(event, message)
    if not success:
        raise HTTPException(status_code=500, detail='Streamlabs API error')
    return {'status': 'alert sent'}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host=os.getenv('HOST','0.0.0.0'), port=int(os.getenv('PORT',8000)))
