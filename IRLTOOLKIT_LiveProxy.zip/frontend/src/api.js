import axios from 'axios';
export const startStream=()=>axios.post('/control/start');
export const stopStream=()=>axios.post('/control/stop');
export const switchSource=i=>axios.post(`/control/switch/${i}`);
export const getStatus=()=>axios.get('/control/status');
export const getSources=()=>axios.get('/control/sources');
export const sendAlert=(e,m)=>axios.post('/alerts/streamlabs',{event:e,message:m});
