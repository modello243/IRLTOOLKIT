import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import Chart from 'chart.js/auto';
import './tailwind.css';

const App = () => {
    const [status, setStatus] = useState({ running: false, current_source: '', buffer_files: [], is_offline: false });
    const [sources, setSources] = useState([]);
    const [alertEvent, setAlertEvent] = useState('notification');
    const [alertMessage, setAlertMessage] = useState('');
    const [chart, setChart] = useState(null);

    useEffect(() => {
        fetchStatus();
        fetchSources();
        const interval = setInterval(fetchStatus, 5000);
        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        if (chart) chart.destroy();
        const ctx = document.getElementById('bitrateChart').getContext('2d');
        const newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array(60).fill('').map((_, i) => i),
                datasets: [{ label: 'Bitrate (kbps)', data: Array(60).fill(0), borderColor: 'rgba(75, 192, 192, 1)', fill: false }]
            },
            options: { scales: { y: { beginAtZero: true } } }
        });
        setChart(newChart);
    }, [sources]);

    const fetchStatus = async () => {
        const response = await axios.get('/control/status');
        setStatus(response.data);
        if (chart) {
            chart.data.datasets[0].data.shift();
            chart.data.datasets[0].data.push(Math.random()*1000);
            chart.update();
        }
    };
    const fetchSources = async () => {
        const response = await axios.get('/control/sources');
        setSources(response.data.sources);
    };
    const startStream = async () => { await axios.post('/control/start'); fetchStatus(); };
    const stopStream = async () => { await axios.post('/control/stop'); fetchStatus(); };
    const switchSource = async i => { await axios.post(`/control/switch/${i}`); fetchStatus(); };
    const sendAlert = async () => { await axios.post('/alerts/streamlabs', { event: alertEvent, message: alertMessage }); setAlertMessage(''); };

    return (
        <div className="min-h-screen bg-gray-100 p-4">
            <h1 className="text-3xl font-bold text-center mb-6">IRLTOOLKIT Live Proxy</h1>
            <div className="bg-white shadow rounded-lg p-4 mb-4">
                <h2 className="text-xl font-semibold mb-2">Stream Status</h2>
                <p><strong>Running:</strong> {status.running?'Yes':'No'}</p>
                <p><strong>Source:</strong> {status.current_source}</p>
                <p><strong>Offline:</strong> {status.is_offline?'Yes':'No'}</p>
                <p><strong>Buffers:</strong> {status.buffer_files.length}</p>
                <canvas id="bitrateChart" className="mt-4"></canvas>
            </div>
            <div className="bg-white shadow rounded-lg p-4 mb-4">
                <h2 className="text-xl font-semibold mb-2">Controls</h2>
                <div className="flex space-x-4">
                    <button onClick={startStream} className="bg-green-500 text-white px-4 py-2 rounded">Start</button>
                    <button onClick={stopStream} className="bg-red-500 text-white px-4 py-2 rounded">Stop</button>
                </div>
                <h3 className="text-lg font-semibold mt-4">Switch Source</h3>
                <div className="flex space-x-2">{sources.map((s,i)=><button key={i} onClick={()=>switchSource(i)} className="bg-blue-500 text-white px-4 py-2 rounded">#{i+1}</button>)}</div>
            </div>
            <div className="bg-white shadow rounded-lg p-4 mb-4">
                <h2 className="text-xl font-semibold mb-2">Alert</h2>
                <input value={alertEvent} onChange={e=>setAlertEvent(e.target.value)} className="w-full p-2 mb-2 border rounded" placeholder="Event"/>
                <input value={alertMessage} onChange={e=>setAlertMessage(e.target.value)} className="w-full p-2 mb-2 border rounded" placeholder="Message"/>
                <button onClick={sendAlert} className="bg-purple-500 text-white px-4 py-2 rounded">Send</button>
            </div>
            <div className="bg-white shadow rounded-lg p-4">
                <h2 className="text-xl font-semibold mb-2">Config</h2>
                <p><strong>Sources:</strong> {sources.join(', ')}</p>
                <p className="text-gray-500">Edit .env for changes</p>
            </div>
        </div>
    );
};

ReactDOM.render(<App />, document.getElementById('root'));
