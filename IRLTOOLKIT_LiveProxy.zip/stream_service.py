import asyncio
import subprocess
import os
import logging
from typing import List

logger = logging.getLogger("StreamService")
logging.basicConfig(level=logging.INFO)

class StreamIngestService:
    def __init__(self, sources: List[str], srt_key: str, hls_dir: str = "./hls_buffer", buffer_segments: int = 5, brb_playlist: str = "./brb.m3u8"):
        self.sources = sources
        self.current = 0
        self.srt_key = srt_key
        self.hls_dir = hls_dir
        self.buffer_segments = buffer_segments
        self.brb_playlist = brb_playlist
        self.proc = None
        self.is_offline = False
        os.makedirs(self.hls_dir, exist_ok=True)
        self._create_brb_playlist()

    def _create_brb_playlist(self):
        """Create a fallback BRB playlist for offline buffering."""
        brb_content = """#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:2
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:2.0,
brb.ts
#EXT-X-ENDLIST
"""
        with open(self.brb_playlist, 'w') as f:
            f.write(brb_content)
        # Placeholder for brb.ts (in practice, this should be a pre-encoded video file)
        with open(os.path.join(self.hls_dir, 'brb.ts'), 'w') as f:
            f.write("Placeholder BRB video segment")

    async def start(self):
        """Start the stream ingest process."""
        await self.stop()
        src = self.sources[self.current]
        url = f"{src}?passphrase={self.srt_key}"
        cmd = [
            "ffmpeg", "-hide_banner", "-loglevel", "error",
            "-i", url,
            "-c", "copy",
            "-f", "hls",
            "-hls_time", "2",
            "-hls_list_size", str(self.buffer_segments),
            "-hls_flags", "delete_segments+independent_segments",
            os.path.join(self.hls_dir, "index.m3u8")
        ]
        logger.info(f"Starting ingest with source: {src}")
        self.proc = subprocess.Popen(cmd)
        self.is_offline = False
        asyncio.create_task(self._monitor())

    async def _monitor(self):
        """Monitor the FFmpeg process and switch to BRB playlist on failure."""
        while True:
            if self.proc and self.proc.poll() is not None:
                logger.warning("Stream ingest stopped unexpectedly. Switching to BRB playlist...")
                self.is_offline = True
                shutil.copy(self.brb_playlist, os.path.join(self.hls_dir, "index.m3u8"))
                await asyncio.sleep(5)  # Wait before retrying
                await self.start()
                return
            await asyncio.sleep(1)

    async def stop(self):
        """Stop the ingest process and clear the buffer."""
        if self.proc and self.proc.poll() is None:
            logger.info("Stopping ingest...")
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except Exception:
                self.proc.kill()
        self.is_offline = False
        for f in os.listdir(self.hls_dir):
            if f != 'brb.ts':
                os.remove(os.path.join(self.hls_dir, f))

    async def switch_source(self, index: int):
        """Switch to a different source."""
        if 0 <= index < len(self.sources):
            logger.info(f"Switching source to {self.sources[index]}")
            self.current = index
            await self.start()
        else:
            raise IndexError("Invalid source index")

    def status(self):
        """Return the current status of the service."""
        return {
            "running": bool(self.proc and self.proc.poll() is None),
            "current_source": self.sources[self.current] if self.sources else None,
            "buffer_files": os.listdir(self.hls_dir),
            "is_offline": self.is_offline
        }

    def get_sources(self):
        """Return the list of configured sources."""
        return self.sources
