# IRLTOOLKIT Live Proxy

A robust streaming proxy designed for offline protection, seamless source switching (desktop ↔ phone), Streamlabs alerts, and a web-based GUI for easy control.

## Features

- Offline buffering: Retains last N HLS segments and serves a "Be Right Back" (BRB) playlist during outages.
- Auto reconnect on SRT drop.
- Multi-source failover (desktop ↔ phone).
- Streamlabs alert notifications.
- REST API control.
- CLI commands.
- Web-based GUI for stream control, status monitoring, and alert management.

## Requirements

- Python 3.9+
- FFmpeg installed and in PATH.
- Node.js and npm for building the GUI.
- Dependencies from requirements.txt.

## Installation

```bash
git clone https://github.com/youruser/IRLTOOLKIT_LiveProxy.git
cd IRLTOOLKIT_LiveProxy
cp .env.example .env
pip install -r requirements.txt
cd frontend
npm install
npm run build
cd .. 
```